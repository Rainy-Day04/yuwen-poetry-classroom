# 大语文 诗词课堂

Desktop-first poetry presentation website for a teacher-led classroom.

## Content

- The provided curriculum PDF supplies 70 entries across grades 1–3 (22, 23, 25). Original text and excerpt boundaries are preserved; these are source-reading pages, not complete lessons.
- The supplied Jiang Xue Word example is adapted into 11 presentation pages covering reading, interpretation, discussion, vocabulary, and painting comparison. It is a separate demonstration lesson, not assigned a grade absent a curriculum decision.
- `public/hanjiang.jpg` is the painting embedded in the user-provided example, with attribution shown in the lesson.

## Controls

Left/right arrows and Page Up/Page Down navigate the lesson. Space advances when a button or other control is not focused. F toggles fullscreen. The sidebar jumps to a teaching section. Dots navigate directly to each page. Prompts are initially hidden and can be revealed or hidden again.

## Development

Run `npm install`, then `npm run dev`. Run `npm run build` for the deployment build and `npx tsc --noEmit` for type checking. Content is in `app/catalog.json`; the sample and presentation layouts are in `app/page.tsx`.
