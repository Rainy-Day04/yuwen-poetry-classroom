import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: '大语文 · 诗词课堂',
  icons: { icon: '/favicon.svg' },
  description: '面向课堂大屏的古诗词教学。读一读、赏一赏、想一想、学一学、比一比。',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body>
        {children}
      </body>
    </html>
  );
}
