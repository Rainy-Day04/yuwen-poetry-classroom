'use client';
import { useEffect, useState } from 'react';
import { ArrowLeft, ArrowRight, ChevronRight, Expand, Minimize, Grid2X2, Eye, EyeOff, Feather, X } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import catalog from './catalog.json';

const sections=['读一读','赏一赏','想一想','学一学','比一比'];
const subtitles=['走进诗的世界','看见字里行间','让想象发生','从一个字出发','诗与画的相遇'];
const slides=[
 {section:0,title:'在寂静中，读一首诗',kind:'poem'},
 {section:1,title:'把诗句，读成一幅画',kind:'translation'},
 {section:1,title:'一首诗背后的柳宗元',kind:'author'},
 {section:1,title:'天地很大，身影很小',kind:'contrast'},
 {section:2,title:'如果这幅画，有了声音……',kind:'question',question:'你觉得会听见什么？\n还是没有声音？',hint:'可以想象风声、雪落下的声音，或渔线碰到水面的声音。再回到“鸟飞绝”“人踪灭”，说说你的依据。'},
 {section:2,title:'他为什么，还在这里？',kind:'question',question:'这么冷、这么安静，\n老人为什么还要独钓？',hint:'也许是等待，也许是享受安静，也许是一种坚持。没有唯一答案，试着用诗里的一个字或一句话支持自己的想法。'},
 {section:3,title:'同一个“独”，不同的心情',kind:'word'},
 {section:3,title:'一个身影，一份坚持',kind:'extension'},
 {section:4,title:'诗里有画，画外有诗',kind:'painting'},
 {section:4,title:'留白，给想象一个地方',kind:'blank'},
 {section:0,title:'再读江雪，你读到了什么？',kind:'recap'},
];
const verse=['千山鸟飞绝，','万径人踪灭。','孤舟蓑笠翁，','独钓寒江雪。'];
const pinyin=['qiān shān niǎo fēi jué','wàn jìng rén zōng miè','gū zhōu suō lì wēng','dú diào hán jiāng xuě'];
const translations=['群山之中，已看不见飞鸟的踪影。','条条山路，都没有行人的足迹。','一叶孤舟上，坐着披蓑衣、戴斗笠的老人。','他独自垂钓，面对着寒冷江面上的漫天风雪。'];
export default function Home(){
 const [view,setView]=useState<'catalog'|'lesson'>('catalog');
 const [grade,setGrade]=useState(1);
 const [step,setStep]=useState(0);
 const [showPinyin,setShowPinyin]=useState(true);
 const [reveal,setReveal]=useState(false);
 const [fullscreen,setFullscreen]=useState(false);
 const [selected,setSelected]=useState<(typeof catalog)[number]|null>(null);
 const [notice,setNotice]=useState('');
 const current=slides[step];
 const isSample=!selected;
 const total=isSample?slides.length:Math.max(1,Math.ceil(selected.lines.length/4));
 function go(n:number){setStep(Math.max(0,Math.min(total-1,n)));setReveal(false);}
 function openLesson(poem:(typeof catalog)[number]|null){setSelected(poem);setStep(0);setReveal(false);setView('lesson');window.scrollTo(0,0);}
 async function toggleFull(){try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch{setNotice('当前浏览器未开启全屏，请使用浏览器的全屏菜单。');}}
 useEffect(()=>{const f=()=>setFullscreen(Boolean(document.fullscreenElement));document.addEventListener('fullscreenchange',f);return()=>document.removeEventListener('fullscreenchange',f);},[]);
 useEffect(()=>{function key(e:KeyboardEvent){const target=e.target instanceof HTMLElement?e.target:null;if(target&&(['INPUT','TEXTAREA'].includes(target.tagName)||target.isContentEditable||target.closest('[role="tablist"]')))return;if(view==='lesson'){if(['ArrowRight','PageDown'].includes(e.key)||(e.key===' '&&!target?.closest('button'))){e.preventDefault();go(step+1);}if(['ArrowLeft','PageUp'].includes(e.key)){e.preventDefault();go(step-1);}if(e.key==='Home'){e.preventDefault();go(0);}if(e.key==='End'){e.preventDefault();go(total-1);}}if(e.key.toLowerCase()==='f'){e.preventDefault();toggleFull();}}window.addEventListener('keydown',key);return()=>window.removeEventListener('keydown',key);},[view,step,total]);
 const poemBlock=(recap=false)=><div className={'poem-block '+(recap?'recap-poem':'')}><div className="poem-name">江雪<span className="seal">柳</span></div><p className="poem-author">唐 · 柳宗元</p><div className="verse">{verse.map((line,i)=><p key={line}>{Array.from(line).map((char,j)=><ruby key={j}>{char}<rt>{showPinyin&&j<5?pinyin[i].split(' ')[j]:''}</rt></ruby>)}</p>)}</div></div>;
 return <main className="app-shell">
 <header className="app-header"><button className="brand" onClick={()=>setView('catalog')} aria-label="返回诗歌目录"><span className="brand-mark">文</span><span>大语文<span className="brand-divider">/</span><span className="brand-sub">诗词课堂</span></span></button><div className="header-right"><span className="classroom-label">小学 · 一至三年级</span><button className="icon-button" onClick={toggleFull} title="全屏 F" aria-label={fullscreen?'退出全屏':'全屏展示'}>{fullscreen?<Minimize size={19}/>:<Expand size={19}/>}</button></div></header>
 {notice&&<div role="status" className="notice">{notice}<button onClick={()=>setNotice('')} aria-label="关闭提示"><X size={16}/></button></div>}
 {view==='catalog'?<div className="catalog-page">
 <div className="catalog-heading"><div><p className="eyebrow">诗词课堂 · 课程目录</p><h1>从一首诗，<br/>走进一方天地<span className="red-dot">。</span></h1></div><div className="catalog-intro"><p>读诗，赏景，想象，发现。</p><p>选择一首诗，开启今天的课堂。</p></div></div>
 <button className="featured" onClick={()=>openLesson(null)}><div className="featured-text"><span className="small-label">完整示范课 <span>01</span></span><div className="featured-title">江雪 <span>唐 · 柳宗元</span></div><p>千山鸟飞绝，万径人踪灭。</p><span className="featured-action">进入课堂 <ArrowRight size={18}/></span></div><div className="featured-art"><img src="/hanjiang.jpg" alt="寒江独钓图：一叶孤舟与垂钓者，四周大片留白"/><span>独 · 寂静 · 坚持</span></div></button>
 <div className="catalog-toolbar"><Tabs value={String(grade)} onValueChange={v=>setGrade(Number(v))}><TabsList className="grade-tabs" variant="line">{[1,2,3].map(g=><TabsTrigger key={g} value={String(g)}>{['一','二','三'][g-1]}年级 <span>{[22,23,25][g-1]}</span></TabsTrigger>)}</TabsList></Tabs><span className="source-label">篇目原文 · 按课程顺序</span></div>
 <div className="poem-grid">{catalog.filter(p=>p.grade===grade).map(p=><button key={p.id} className="poem-card" onClick={()=>openLesson(p)}><span className="poem-number">{String(p.order).padStart(2,'0')}</span><div><h2>{p.title}</h2><p>{p.author||'经典蒙学'}</p></div><ChevronRight size={18}/></button>)}</div>
 <footer className="catalog-footer"><span>大语文 · 在诗里认识世界</span><span>《江雪》为完整示范课，其余篇目已收录原文。</span></footer>
 </div>:<div className="lesson-layout">
 <aside className="lesson-nav"><button className="back-link" onClick={()=>setView('catalog')}><ArrowLeft size={17}/>诗歌目录</button><div className="lesson-identity"><span className="eyebrow">{isSample?'完整示范课':`${['一','二','三'][(selected?.grade||1)-1]}年级 · 原文`}</span><h1>{selected?.title||'江雪'}</h1><p>{selected?.author||'唐 · 柳宗元'}</p></div><nav aria-label="教学环节">{(isSample?sections:['读一读']).map((s,i)=><button key={s} className={'section-button '+((isSample?current.section:0)===i?'active':'')} onClick={()=>go(isSample?slides.findIndex(x=>x.section===i):0)}><span className="section-number">0{i+1}</span><span>{s}<small>{subtitles[i]}</small></span><ChevronRight size={15}/></button>)}</nav><div className="nav-bottom"><Feather size={21}/><p>一字一句，<br/>慢慢读，慢慢想。</p></div></aside>
 <div className="lesson-main"><div className="lesson-topline"><span>{isSample?sections[current.section]:'读一读'}<span className="breadcrumb-separator">/</span>{isSample?subtitles[current.section]:'诗歌原文'}</span><div className="lesson-options">{isSample&&(current.kind==='poem'||current.kind==='recap')&&<label>拼音<Switch checked={showPinyin} onCheckedChange={setShowPinyin} aria-label="显示拼音"/></label>}<span className="lesson-kind">课堂展示</span></div></div>
 <article key={`${selected?.id||'sample'}-${step}`} className={'slide slide-'+(isSample?current.kind:'source')}>
 <div className="slide-heading"><span className="eyebrow">{isSample?`0${current.section+1} / ${sections[current.section]}`:'01 / 读一读'}</span><h2>{isSample?current.title:selected.title}</h2></div>
 {!isSample?<div className="source-poem"><p className="poem-author">{selected.author}</p>{selected.lines.slice(step*4,step*4+4).map((line,i)=><p className="source-line" key={i}>{line}</p>)}<span className="source-note">依课程篇目资料收录</span></div>:<>
 {current.kind==='poem'&&<div className="poem-scene">{poemBlock()}<div className="poem-side-note"><span>五言绝句</span><span>二十个字，一片天地。</span></div></div>}
 {current.kind==='translation'&&<div className="translation-list">{verse.map((v,i)=><div key={v}><span className="line-index">0{i+1}</span><h3>{v}</h3><p>{translations[i]}</p></div>)}</div>}
 {current.kind==='author'&&<div className="author-layout"><div className="author-name">柳<br/>宗<br/>元<span>唐代文学家</span></div><div className="author-story"><p className="large-prose">改革失败后，<br/>他来到遥远的永州。</p><p>柳宗元曾参与政治改革，失败后被贬到永州。《江雪》大约写于这一时期。</p><p>他没有直接说出自己的心情，<br/>而是写下了一片雪、一条江、一个人。</p><div className="thought-line">读诗时，可以留意：<strong>风景里，藏着怎样的心情？</strong></div></div></div>}
 {current.kind==='contrast'&&<div className="contrast-layout"><div className="contrast-pair"><div><span>天地之大</span><strong>千山<span>万径</span></strong><p>远处，辽阔的山与路</p></div><span className="versus">与</span><div><span>人物之少</span><strong>孤舟<span>独钓</span></strong><p>近处，独自垂钓的老人</p></div></div><div className="contrast-bottom"><span>大与小</span><span>多与少</span><span>远与近</span></div><p className="closing-line">没有写“孤独”，却让我们感受到了孤独。</p></div>}
 {current.kind==='question'&&<div className="question-layout"><span className="big-quote">“</span><h3>{current.question?.split('\n').map((l,i)=><span key={i}>{l}<br/></span>)}</h3><p className="question-instruction">先说说你的想法，再从诗句中找找依据。</p><button className="reveal-button" aria-expanded={reveal} onClick={()=>setReveal(!reveal)}>{reveal?<EyeOff size={18}/>:<Eye size={18}/>} {reveal?'收起思考提示':'展开思考提示'}</button>{reveal&&<p className="hint">{current.hint}</p>}</div>}
 {current.kind==='word'&&<div className="word-layout"><div className="single-word">独<small>独自 · 一个人</small></div><div className="word-comparisons"><div><span>柳宗元 · 江雪</span><h3><em>独</em>钓寒江雪。</h3><p>在寒冷、寂静的天地中，孤清而坚定。</p></div><div><span>王维 · 九月九日忆山东兄弟</span><h3><em>独</em>在异乡为异客，<br/>每逢佳节倍思亲。</h3><p>身在远方，思念家乡与亲人。</p></div></div></div>}
 {current.kind==='extension'&&<div className="extension-layout"><p className="eyebrow">诗句拓展</p><h3>独钓寒江</h3><p>一个人，在寂静或艰难的环境里，<br/>仍然坚持自己的事情。</p><div className="keyword-row"><span>清醒</span><span>坚定</span><span>不随波逐流</span></div><button className="reveal-button" onClick={()=>setReveal(!reveal)} aria-expanded={reveal}><Eye size={18}/>想一想生活中的“坚持”</button>{reveal&&<p className="hint">你有没有独自坚持做一件事情？当时的心情，和诗中的老人一样吗？</p>}</div>}
 {current.kind==='painting'&&<div className="painting-layout"><figure><img src="/hanjiang.jpg" alt="马远《寒江独钓图》，舟上老人独钓，大片空白环绕"/><figcaption>《寒江独钓图》 · 南宋 · 马远 <span>图片来自所提供的教学示例</span></figcaption></figure><div className="painting-verse"><p>孤舟蓑笠翁，<br/>独钓寒江雪。</p><span>诗中的“千山万径”，<br/>在画里去了哪里？</span></div></div>}
 {current.kind==='blank'&&<div className="blank-layout"><div className="blank-image"><img src="/hanjiang.jpg" alt="寒江独钓图中的大面积留白"/></div><div><span className="eyebrow">一起讨论</span><h3>画得少，<br/>为什么反而觉得<br/>天地更大？</h3><p>如果把空白画满山、树和人，<br/>会有什么不同？</p><button className="reveal-button" onClick={()=>setReveal(!reveal)} aria-expanded={reveal}><Eye size={18}/>再想深一点</button>{reveal&&<p className="hint">什么时候“满”一点好？什么时候“空”一点，反而能留下想象和思考的地方？</p>}</div></div>}
 {current.kind==='recap'&&<div className="recap-layout">{poemBlock(true)}<div><span className="eyebrow">带着新的感受，再读一遍</span><h3>你会把哪个字，<br/>读得更慢一些？</h3><div className="keyword-row"><span>独</span><span>寂静</span><span>坚持</span></div><button className="reveal-button" onClick={()=>go(0)}>回到诗的开头 <ArrowRight size={18}/></button></div></div>}
 </>}
 </article><footer className="lesson-footer"><span className="keyboard-hint">← → 翻页<span>F 全屏</span></span><div className="page-dots" aria-label="课堂页面">{Array.from({length:total},(_,i)=><button key={i} onClick={()=>go(i)} aria-label={`第${i+1}页`} aria-current={step===i?'step':undefined} className={step===i?'active':''}/>)}</div><div className="page-controls"><span>{String(step+1).padStart(2,'0')}<small> / {String(total).padStart(2,'0')}</small></span><button className="icon-button" aria-label="上一页" disabled={step===0} onClick={()=>go(step-1)}><ArrowLeft size={20}/></button><button className="next-button" aria-label={step===total-1?'返回目录':'下一页'} onClick={()=>step===total-1?setView('catalog'):go(step+1)}>{step===total-1?<Grid2X2 size={20}/>:<ArrowRight size={20}/>}</button></div></footer>
 </div></div>}
 </main>
}
